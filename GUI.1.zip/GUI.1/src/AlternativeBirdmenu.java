import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AlternativeBirdmenu extends JFrame {
    private JLabel myLabel0;
    private JLabel myLabel1;
    private JLabel myLabel2;
    private JPanel myPanel;

    public AlternativeBirdmenu(){
        super("YOUR SMART BIRD FEEDER INTERFACE");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        myPanel = new JPanel();

        myLabel0 = new JLabel();
        myLabel0.setText("Bird Menu");
        myLabel0.setBounds(230,0,600,80);
        myLabel0.setFont(new Font("Gill Sans Ultra Bold Condensed",Font.PLAIN,30));
        myPanel.add(myLabel0);
        myLabel1 = new JLabel();
        myLabel1.setOpaque(true);
        myLabel1.setBackground(Color.black);
        myLabel1.setBounds(0,65,600,2);
        //myLabel1.setFont(new Font("",Font.PLAIN,30));
        myPanel.add(myLabel1);


        this.setContentPane(myPanel);
    }
    public static void main(String[] args){
        JFrame test = new AlternativeBirdmenu();
        test.setLayout(null);
        test.setSize(600,800);
        test.setResizable(false);
        test.setVisible(true);


        //Create the back button
        JButton myButton1 = new JButton();
        myButton1.setText("<");
        myButton1.setBounds(10,10,50,50);
        myButton1.setFont(new Font("Gill Sans Ultra Bold Condensed",Font.BOLD,15));
        myButton1.setBackground(Color.white);

        test.add(myButton1);
        myButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                test.dispose();
                //String [] arguments = new String[] {""};
                //MainPage.main(user);
            }
        });

        JButton myButton2 = new JButton();
        myButton2.setText("0 gram - 25 gram ");
        myButton2.setBounds(10,120,200,100);
        myButton2.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton2.setBackground(Color.white);
        test.add(myButton2);

        JButton myButton3 = new JButton();
        myButton3.setText("25 gram - 100 gram ");
        myButton3.setBounds(10,260,200,100);
        myButton3.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton3.setBackground(Color.white);
        test.add(myButton3);

        JButton myButton4 = new JButton();
        myButton4.setText("100 gram - 200 gram ");
        myButton4.setBounds(10,400,200,100);
        myButton4.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton4.setBackground(Color.white);
        test.add(myButton4);

        JButton myButton5 = new JButton();
        myButton5.setText("200+ gram ");
        myButton5.setBounds(10,540,200,100);
        myButton5.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton5.setBackground(Color.white);
        test.add(myButton5);

        JButton myButton6 = new JButton();
        myButton6.setText("Give access");
        myButton6.setBounds(230,540,150,100);
        myButton6.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton6.setBackground(Color.white);
        test.add(myButton6);

        JButton myButton7 = new JButton();
        myButton7.setText("Deny access");
        myButton7.setBounds(400,540,150,100);
        myButton7.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton7.setBackground(Color.white);
        test.add(myButton7);

        JButton myButton8 = new JButton();
        myButton8.setText("Give access");
        myButton8.setBounds(230,400,150,100);
        myButton8.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton8.setBackground(Color.white);
        test.add(myButton8);

        JButton myButton9 = new JButton();
        myButton9.setText("Deny access");
        myButton9.setBounds(400,400,150,100);
        myButton9.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton9.setBackground(Color.white);
        test.add(myButton9);

        JButton myButton10 = new JButton();
        myButton10.setText("Give access");
        myButton10.setBounds(230,260,150,100);
        myButton10.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton10.setBackground(Color.white);
        test.add(myButton10);

        JButton myButton11 = new JButton();
        myButton11.setText("Deny access");
        myButton11.setBounds(400,260,150,100);
        myButton11.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton11.setBackground(Color.white);
        test.add(myButton11);

        JButton myButton12 = new JButton();
        myButton12.setText("Give access");
        myButton12.setBounds(230,120,150,100);
        myButton12.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton12.setBackground(Color.white);
        test.add(myButton12);

        JButton myButton13 = new JButton();
        myButton13.setText("Deny access");
        myButton13.setBounds(400,120,150,100);
        myButton13.setFont(new Font("Ebrima",Font.BOLD,15));
        myButton13.setBackground(Color.white);
        test.add(myButton13);



    }

}
