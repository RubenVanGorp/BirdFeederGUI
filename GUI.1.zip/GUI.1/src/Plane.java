import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class Plane extends JFrame {
    private JLabel line;
    private JLabel planeInfo;


    private JTextField myTextField;

    public Plane(String title,ArrayList<String> birdNames ,ArrayList<String> birdPictures ,int min,int max,int start){
        super("YOUR SMART BIRD FEEDER INTERFACE");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JPanel myPanel = new JPanel();



        line = new JLabel();
        line.setOpaque(true);
        line.setBackground(Color.black);
        line.setBounds(0,65,600,2);
        //line.setFont(new Font("",Font.PLAIN,30));
        myPanel.add(line);

        /*
        // Create weight Label
        planeInfo = new JLabel();
        planeInfo.setText("weight range:  "+min+" g  -  "+max+" g");
        planeInfo.setFont(new Font("Ebrima",Font.PLAIN,15));
        planeInfo.setBounds(195,350,300,50);
        myPanel.add(planeInfo);


        // Create Titel Label
        myLabel3 = new JLabel();
        myLabel3.setText(bird);
        myLabel3.setFont(new Font("Ebrima",Font.PLAIN,20));
        myLabel3.setBounds(200,100,300,50);
        myPanel.add(myLabel3);


        icon = new ImageIcon(birdFile);
        myLabel4 = new JLabel();
        myLabel4.setIcon(icon);
        myLabel4.setOpaque(true);
        myLabel4.setBounds(200,150,200,200);
        myPanel.add(myLabel4);

         */

        // Create weight Label
        planeInfo = new JLabel();
        planeInfo.setText("This weight range includes, among others, the following birds :");
        planeInfo.setFont(new Font("Ebrima",Font.PLAIN,15));
        planeInfo.setBounds(10,100,600,50);
        myPanel.add(planeInfo);

        int interval = 0;

        for (int i = 0; i < birdNames.size(); i++)
        {
            if (i > 3)
            {
                if (i==4)
                {
                    interval=0;
                    JLabel textLabel = new JLabel();
                    textLabel.setText(birdNames.get(i));
                    textLabel.setBounds(15 + interval,450,500,50);
                    myPanel.add(textLabel);

                    ImageIcon icon = new ImageIcon(birdPictures.get(i));
                    JLabel picLabel = new JLabel();
                    picLabel.setIcon(icon);
                    picLabel.setOpaque(true);
                    picLabel.setBounds(15 + interval,350,100,100);
                    myPanel.add(picLabel);

                    interval = interval + 150;
                }
                else
                {
                    JLabel textLabel = new JLabel();
                    textLabel.setText(birdNames.get(i));
                    textLabel.setBounds(15 + interval,450,500,50);
                    myPanel.add(textLabel);

                    ImageIcon icon = new ImageIcon(birdPictures.get(i));
                    JLabel picLabel = new JLabel();
                    picLabel.setIcon(icon);
                    picLabel.setOpaque(true);
                    picLabel.setBounds(15 + interval,350,100,100);
                    myPanel.add(picLabel);

                    interval = interval + 150;


                }

            }
            else
            {
                JLabel textLabel = new JLabel();
                textLabel.setText(birdNames.get(i));
                textLabel.setBounds(15 + interval,275,500,50);
                myPanel.add(textLabel);

                ImageIcon icon = new ImageIcon(birdPictures.get(i));
                JLabel picLabel = new JLabel();
                picLabel.setIcon(icon);
                picLabel.setOpaque(true);
                picLabel.setBounds(15 + interval,175,100,100);
                myPanel.add(picLabel);

                interval = interval + 150;
            }

        }


        //myPanel op JFrame zetten
        this.setContentPane(myPanel);

    }


    public static void main(String user, String title, ArrayList<String> birdNames,ArrayList<String> birdPictures,int min,int max, int start) {
        //generate my UI
        JFrame test= new Plane(title, birdNames ,birdPictures,min,max,start);
        //the frame needs to become visible
        test.setLayout(null);
        test.setSize(600,800);
        test.setResizable(false);
        test.setVisible(true);
        //ui.pack();

        JLabel planeTitle = new JLabel();
        planeTitle.setText(title);
        planeTitle.setBounds(200,0,600,80);
        planeTitle.setFont(new Font("Gill Sans Ultra Bold Condensed",Font.PLAIN,30));
        test.add(planeTitle);

        //Create the back button
        JButton myButton1 = new JButton();
        myButton1.setText("<");
        myButton1.setBounds(10,10,50,50);
        myButton1.setBackground(Color.white);
        myButton1.setFont(new Font("Gill Sans Ultra Bold Condensed",Font.BOLD,15));
        test.add(myButton1);

        myButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] arguments = new String[] {""};
                BirdMenu.main(user);
                test.dispose();
            }
        });

        /*
        //Create Remove button
        JButton myButton4 = new JButton();
        myButton4.setText("REMOVE");
        myButton4.setBounds(160,540,120,80);
        myButton4.setBackground(Color.white);
        myButton4.setFont(new Font("Ebrima",Font.PLAIN,15));
        test.add(myButton4);

        myButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame confirmation = new JFrame();
                JOptionPane.showMessageDialog(confirmation, bird +" successfully removed from birds fed.");

                //Remove bird
                DBMethods db = new DBMethods();
                String response = db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/RemoveBird/"+bird);


                //Open the bird menu
                String[] arguments = new String[] {""};
                BirdMenu.main(user);
                test.dispose();


            }
        });

        JButton myButton5 = new JButton();
        myButton5.setText("ADD");
        myButton5.setBounds(320,540,120,80);
        myButton5.setBackground(Color.white);
        myButton5.setFont(new Font("Ebrima",Font.PLAIN,15));
        test.add(myButton5);
        myButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //Find out if bird is already in db or not
                boolean alreadyAdded = false;
                DBMethods db = new DBMethods();
                String names = db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/GetBirdNames");
                ArrayList<String> lijst = db.returnJSONNames(names);
                for(String name: lijst){
                    if(name.equals(bird)==true){
                        alreadyAdded = true;
                    }
                }

                //Add if the bird isn't in the db yet
                if(alreadyAdded == false){
                    int index = lijst.size() + 1 ;
                    db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddBird/"+index+"/"+bird+"/"+min+"/"+max);
                    JFrame confirmation = new JFrame();
                    JOptionPane.showMessageDialog(confirmation, bird +" successfully added to birds fed.");
                }
                //Show frame if bird is already added
                else{
                    JFrame already = new JFrame();
                    JOptionPane.showMessageDialog( already,bird +" was already added");
                }


                //Back to bird menu
                String[] arguments = new String[] {""};
                BirdMenu.main(user);
                test.dispose();

            }
        });

         */
        JButton myButton4 = new JButton();
        myButton4.setText("GIVE ACCESS");
        myButton4.setBounds(130,540,150,80);
        myButton4.setBackground(Color.white);
        myButton4.setFont(new Font("Ebrima",Font.PLAIN,15));
        test.add(myButton4);

        myButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //Remove bird
                DBMethods db = new DBMethods();
                if(birdNames.get(0).equals("chaffinch")){
                    db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+1);
                    db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddUnder25");
                }
                else{
                    if(birdNames.get(0).equals("house sparrow")){
                        db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+2);
                        db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddUnder100");
                    }
                    else{
                        if(birdNames.get(0).equals("blackbird")){
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+3);
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddUnder200");
                        }
                        else{
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+4);
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddOver200");
                        }
                    }
                }

                JFrame confirmation = new JFrame();
                JOptionPane.showMessageDialog(confirmation, "These birds have access now.");

                //Open the bird menu
                String[] arguments = new String[] {""};
                BirdMenu.main(user);
                test.dispose();


            }
        });

        JButton myButton5 = new JButton();
        myButton5.setText("DENY ACCESS");
        myButton5.setBounds(320,540,150,80);
        myButton5.setBackground(Color.white);
        myButton5.setFont(new Font("Ebrima",Font.PLAIN,15));
        test.add(myButton5);
        myButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //Find out if bird is already in db or not
                //boolean alreadyAdded = false;
                DBMethods db = new DBMethods();
                //String names = db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/GetBirdNames");
                //ArrayList<String> lijst = db.returnJSONNames(names);


                if(birdNames.get(0).equals("chaffinch")){
                    db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+1);
                }

                else{
                    if(birdNames.get(0).equals("house sparrow")){
                        db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+2);
                    }
                    else{
                        if(birdNames.get(0).equals("blackbird")){
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+3);
                        }
                        else{
                            db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/ClearCertainBirds/"+4);
                        }
                    }
                }
                /*
                for(String name: lijst){
                    if(name.equals(bird)==true){
                        alreadyAdded = true;
                    }
                }

                //Add if the bird isn't in the db yet
                if(alreadyAdded == false){
                    int index = lijst.size() + 1 ;
                    //db.makeGETRequest("https://studev.groept.be/api/a21ib2c03/AddBird/"+index+"/"+bird+"/"+min+"/"+max);
                    JFrame confirmation = new JFrame();
                    //JOptionPane.showMessageDialog(confirmation, bird +" successfully added to birds fed.");
                }
                //Show frame if bird is already added
                else{
                    JFrame already = new JFrame();
                    //JOptionPane.showMessageDialog( already,bird +" was already added");
                }*/

                JFrame confirmation = new JFrame();
                JOptionPane.showMessageDialog(confirmation, "These birds don't have access anymore.");


                //Back to bird menu
                String[] arguments = new String[] {""};
                BirdMenu.main(user);
                test.dispose();

            }
        });




    }









}
